﻿Public Class Calculadora

    Private operacion As String = ""
    Private numero1 As String = 0
    Private acumulado As String = 0

    Public Sub RealizarOperacion(ByVal cajatexto As TextBox)
        If cajatexto.Text <> "" Then
            Select Case operacion
                Case "+"
                    cajatexto.Text = CDbl(numero1) + CDbl(cajatexto.Text)
                Case "-"
                    cajatexto.Text = CDbl(numero1) - CDbl(cajatexto.Text)
                Case "*"
                    cajatexto.Text = CDbl(numero1) * CDbl(cajatexto.Text)
                Case "/"
                    cajatexto.Text = CDbl(numero1) / CDbl(cajatexto.Text)
                Case "exponente"
                    cajatexto.Text = CDbl(numero1) ^ CDbl(cajatexto.Text)
                Case "exponenteraiz"
                    cajatexto.Text = CDbl(numero1) ^ CDbl(1 / CDbl(cajatexto.Text))
                Case Else
                    cajatexto.Text = "0"
            End Select
            acumulado = "0"
            operacion = ""
            numero1 = "0"
        End If
    End Sub

    Public Sub BorrarTodo(ByVal cajatexto As TextBox)
        acumulado = "0"
        operacion = ""
        numero1 = "0"
        cajatexto.Text = "0"
    End Sub

    Public Function SoloNumeros(ByVal e As KeyPressEventArgs)
        If Char.IsControl(e.KeyChar) Or Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
        Return e
    End Function

    Public Sub PonerOperacion(ByVal cajatexto As TextBox, ByVal opera As String)
        Select Case opera
            Case "suma"
                operacion = "+"
                numero1 = cajatexto.Text
            Case "resta"
                operacion = "-"
                numero1 = cajatexto.Text
            Case "multiplicacion"
                operacion = "*"
                numero1 = cajatexto.Text
            Case "division"
                operacion = "/"
                numero1 = cajatexto.Text
            Case "exponente"
                operacion = "exponente"
                numero1 = cajatexto.Text
            Case "exponenteraiz"
                operacion = "exponenteraiz"
                numero1 = cajatexto.Text
        End Select
        acumulado = "0"
    End Sub

    Public Sub PonerNumeros(ByVal cajatexto As TextBox, ByVal boton As Button)
        If acumulado = "0" Or cajatexto.Text = "" Or cajatexto.Text = "0" Then
            cajatexto.Text = boton.Text
            acumulado = cajatexto.Text
        Else
            cajatexto.Text = acumulado & boton.Text
            acumulado = cajatexto.Text
        End If
    End Sub

    Private Sub Factorial(ByVal cajatexto As TextBox)
        Dim i As Integer
        If cajatexto.Text < 13 Then
            For i = 0 To cajatexto.Text
                cajatexto.Text = cajatexto.Text * i
            Next
        End If
    End Sub

    Public Sub Exponente(ByVal cajatexto As TextBox, ByVal exp As Double)
        cajatexto.Text = CDbl(cajatexto.Text) ^ exp
        acumulado = "0"
    End Sub

    Public Sub Funciones(ByVal cajatexto As TextBox, ByVal funcion As String)
        If cajatexto.Text <> "" And cajatexto.Text <> "0" Then
            Select Case (funcion)
                Case "seno"
                    cajatexto.Text = Math.Sin(CDbl(cajatexto.Text))
                Case "coseno"
                    cajatexto.Text = Math.Cos(CDbl(cajatexto.Text))
                Case "tangente"
                    cajatexto.Text = Math.Tan(CDbl(cajatexto.Text))
                Case "logaritmo"
                    cajatexto.Text = Math.Log10(CDbl(cajatexto.Text))
                Case "ln"
                    cajatexto.Text = Math.Log(CDbl(cajatexto.Text))
                Case "factorial"
                    Factorial(cajatexto)
            End Select
            acumulado = "0"
        End If
    End Sub

    'variables para las posiciones del formulario y saber cuando se puede mover
    Dim ex, ey As Integer
    Dim arrastre As Boolean

    'cada vez que se haga click se van a tomar nuevas posiciones y se pondra en true la variable arrastre para poder mover el formulario
    Private Sub hacer_click_mouse(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        ex = e.X
        ey = e.Y
        arrastre = True
    End Sub

    'para
    Private Sub soltar_click_mouse(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        arrastre = False
    End Sub

    'movemos el formulario si arrastre es true, osea cuando tenemos el click presionado
    Private Sub mover_mouse(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        If arrastre = True Then
            FrmCalculadora.Location = FrmCalculadora.PointToScreen(New Point(Control.MousePosition.X - FrmCalculadora.Location.X - ex, Control.MousePosition.Y - FrmCalculadora.Location.Y - ey))
        End If
    End Sub

    Public Sub AgregarEventos(ByVal frm As Form, ByVal lbl As Label)
        'estos tres siguientes son para el label del titulo
        AddHandler lbl.MouseDown, AddressOf hacer_click_mouse
        AddHandler lbl.MouseUp, AddressOf soltar_click_mouse
        AddHandler lbl.MouseMove, AddressOf mover_mouse
        'estos tres siguientes son para el formulario
        AddHandler frm.MouseDown, AddressOf hacer_click_mouse
        AddHandler frm.MouseUp, AddressOf soltar_click_mouse
        AddHandler frm.MouseMove, AddressOf mover_mouse
    End Sub

End Class
