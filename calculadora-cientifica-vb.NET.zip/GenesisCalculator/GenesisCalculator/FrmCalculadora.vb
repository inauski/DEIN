﻿Public Class FrmCalculadora

    Dim ObjCalc As New Calculadora

    Private Sub FrmCalculadora_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ObjCalc.AgregarEventos(Me, LblTitulo)
    End Sub

    Private Sub BtnBorrarTodo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnBorrarTodo.Click
        ObjCalc.BorrarTodo(TxtResultado)
    End Sub

    Private Sub BtnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnBorrar.Click
        TxtResultado.Text = "0"
    End Sub

    Private Sub BtnExpCuad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnExpCuad.Click
        ObjCalc.Exponente(TxtResultado, 2)
    End Sub

    Private Sub BtnExpCub_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnExpCub.Click
        ObjCalc.Exponente(TxtResultado, 3)
    End Sub

    Private Sub BtnExpN_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnExpN.Click
        ObjCalc.PonerOperacion(TxtResultado, "exponente")
    End Sub

    Private Sub BtnRaizCuad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnRaizCuad.Click
        ObjCalc.Exponente(TxtResultado, 1 / 2)
    End Sub

    Private Sub BtnRaizCub_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnRaizCub.Click
        ObjCalc.Exponente(TxtResultado, 1 / 3)
    End Sub

    Private Sub BtnRaizN_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnRaizN.Click
        ObjCalc.PonerOperacion(TxtResultado, "exponenteraiz")
    End Sub

    Private Sub BtnLogaritmo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnLogaritmo.Click
        ObjCalc.Funciones(TxtResultado, "logaritmo")
    End Sub

    Private Sub BtnLogaritmoNatural_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnLogaritmoNatural.Click
        ObjCalc.Funciones(TxtResultado, "ln")
    End Sub

    Private Sub Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnFactorial.Click
        ObjCalc.Funciones(TxtResultado, "factorial")
    End Sub

    Private Sub BtnSeno_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSeno.Click
        ObjCalc.Funciones(TxtResultado, "seno")
    End Sub

    Private Sub BtnCoseno_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCoseno.Click
        ObjCalc.Funciones(TxtResultado, "coseno")
    End Sub

    Private Sub BtnTangente_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnTangente.Click
        ObjCalc.Funciones(TxtResultado, "tangente")
    End Sub

    Private Sub BtnPunto_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPunto.Click
        If TxtResultado.Text.Contains(",") = False Then
            ObjCalc.PonerNumeros(TxtResultado, BtnPunto)
        End If
    End Sub

    Private Sub BtnUno_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnUno.Click
        ObjCalc.PonerNumeros(TxtResultado, BtnUno)
    End Sub

    Private Sub BtnDos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDos.Click
        ObjCalc.PonerNumeros(TxtResultado, BtnDos)
    End Sub

    Private Sub BtnTres_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnTres.Click
        ObjCalc.PonerNumeros(TxtResultado, BtnTres)
    End Sub

    Private Sub BtnCuatro_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCuatro.Click
        ObjCalc.PonerNumeros(TxtResultado, BtnCuatro)
    End Sub

    Private Sub BtnCinco_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCinco.Click
        ObjCalc.PonerNumeros(TxtResultado, BtnCinco)
    End Sub

    Private Sub BtnSeis_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSeis.Click
        ObjCalc.PonerNumeros(TxtResultado, BtnSeis)
    End Sub

    Private Sub BtnSiete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSiete.Click
        ObjCalc.PonerNumeros(TxtResultado, BtnSiete)
    End Sub

    Private Sub BtnOcho_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnOcho.Click
        ObjCalc.PonerNumeros(TxtResultado, BtnOcho)
    End Sub

    Private Sub BtnNueve_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnNueve.Click
        ObjCalc.PonerNumeros(TxtResultado, BtnNueve)
    End Sub

    Private Sub BtnCero_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCero.Click
        ObjCalc.PonerNumeros(TxtResultado, BtnCero)
    End Sub

    Private Sub BtnResultado_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnResultado.Click
        ObjCalc.RealizarOperacion(TxtResultado)
    End Sub

    Private Sub BtnSuma_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSuma.Click
        ObjCalc.PonerOperacion(TxtResultado, "suma")
    End Sub

    Private Sub BtnResta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnResta.Click
        ObjCalc.PonerOperacion(TxtResultado, "resta")
    End Sub

    Private Sub BtnMultiplicacion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMultiplicacion.Click
        ObjCalc.PonerOperacion(TxtResultado, "multiplicacion")
    End Sub

    Private Sub BtnDivision_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDivision.Click
        ObjCalc.PonerOperacion(TxtResultado, "division")
    End Sub

    Private Sub TxtResultado_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtResultado.KeyPress
        ObjCalc.SoloNumeros(e)
    End Sub

    Private Sub BtnCerrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCerrar.Click
        End
    End Sub

    Private Sub BtnMinimizar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMinimizar.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub LblLink_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LblLink.LinkClicked
        System.Diagnostics.Process.Start(LblLink.Text)
    End Sub

    Private Sub BtnAbout_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles BtnAbout.MouseMove

    End Sub
End Class
