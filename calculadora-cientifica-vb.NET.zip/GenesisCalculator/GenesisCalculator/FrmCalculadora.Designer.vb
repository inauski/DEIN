﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmCalculadora
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmCalculadora))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnBorrarTodo = New System.Windows.Forms.Button()
        Me.BtnPunto = New System.Windows.Forms.Button()
        Me.BtnSeno = New System.Windows.Forms.Button()
        Me.BtnCoseno = New System.Windows.Forms.Button()
        Me.BtnTangente = New System.Windows.Forms.Button()
        Me.BtnLogaritmo = New System.Windows.Forms.Button()
        Me.BtnLogaritmoNatural = New System.Windows.Forms.Button()
        Me.BtnFactorial = New System.Windows.Forms.Button()
        Me.BtnRaizCuad = New System.Windows.Forms.Button()
        Me.BtnRaizCub = New System.Windows.Forms.Button()
        Me.BtnRaizN = New System.Windows.Forms.Button()
        Me.BtnExpCuad = New System.Windows.Forms.Button()
        Me.BtnExpCub = New System.Windows.Forms.Button()
        Me.BtnExpN = New System.Windows.Forms.Button()
        Me.BtnCero = New System.Windows.Forms.Button()
        Me.BtnBorrar = New System.Windows.Forms.Button()
        Me.BtnResultado = New System.Windows.Forms.Button()
        Me.BtnNueve = New System.Windows.Forms.Button()
        Me.BtnSeis = New System.Windows.Forms.Button()
        Me.BtnSiete = New System.Windows.Forms.Button()
        Me.BtnOcho = New System.Windows.Forms.Button()
        Me.BtnCinco = New System.Windows.Forms.Button()
        Me.BtnDos = New System.Windows.Forms.Button()
        Me.BtnTres = New System.Windows.Forms.Button()
        Me.BtnCuatro = New System.Windows.Forms.Button()
        Me.BtnUno = New System.Windows.Forms.Button()
        Me.TxtResultado = New System.Windows.Forms.TextBox()
        Me.BtnResta = New System.Windows.Forms.Button()
        Me.BtnMultiplicacion = New System.Windows.Forms.Button()
        Me.BtnDivision = New System.Windows.Forms.Button()
        Me.BtnSuma = New System.Windows.Forms.Button()
        Me.LblTitulo = New System.Windows.Forms.Label()
        Me.BtnCerrar = New System.Windows.Forms.Button()
        Me.BtnMinimizar = New System.Windows.Forms.Button()
        Me.LblLink = New System.Windows.Forms.LinkLabel()
        Me.BtnAbout = New System.Windows.Forms.Button()
        Me.Tooltip = New System.Windows.Forms.ToolTip(Me.components)
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.BtnAbout)
        Me.Panel1.Controls.Add(Me.LblLink)
        Me.Panel1.Controls.Add(Me.BtnBorrarTodo)
        Me.Panel1.Controls.Add(Me.BtnPunto)
        Me.Panel1.Controls.Add(Me.BtnSeno)
        Me.Panel1.Controls.Add(Me.BtnCoseno)
        Me.Panel1.Controls.Add(Me.BtnTangente)
        Me.Panel1.Controls.Add(Me.BtnLogaritmo)
        Me.Panel1.Controls.Add(Me.BtnLogaritmoNatural)
        Me.Panel1.Controls.Add(Me.BtnFactorial)
        Me.Panel1.Controls.Add(Me.BtnRaizCuad)
        Me.Panel1.Controls.Add(Me.BtnRaizCub)
        Me.Panel1.Controls.Add(Me.BtnRaizN)
        Me.Panel1.Controls.Add(Me.BtnExpCuad)
        Me.Panel1.Controls.Add(Me.BtnExpCub)
        Me.Panel1.Controls.Add(Me.BtnExpN)
        Me.Panel1.Controls.Add(Me.BtnCero)
        Me.Panel1.Controls.Add(Me.BtnBorrar)
        Me.Panel1.Controls.Add(Me.BtnResultado)
        Me.Panel1.Controls.Add(Me.BtnNueve)
        Me.Panel1.Controls.Add(Me.BtnSeis)
        Me.Panel1.Controls.Add(Me.BtnSiete)
        Me.Panel1.Controls.Add(Me.BtnOcho)
        Me.Panel1.Controls.Add(Me.BtnCinco)
        Me.Panel1.Controls.Add(Me.BtnDos)
        Me.Panel1.Controls.Add(Me.BtnTres)
        Me.Panel1.Controls.Add(Me.BtnCuatro)
        Me.Panel1.Controls.Add(Me.BtnUno)
        Me.Panel1.Controls.Add(Me.TxtResultado)
        Me.Panel1.Controls.Add(Me.BtnResta)
        Me.Panel1.Controls.Add(Me.BtnMultiplicacion)
        Me.Panel1.Controls.Add(Me.BtnDivision)
        Me.Panel1.Controls.Add(Me.BtnSuma)
        Me.Panel1.Location = New System.Drawing.Point(3, 36)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(334, 238)
        Me.Panel1.TabIndex = 0
        '
        'BtnBorrarTodo
        '
        Me.BtnBorrarTodo.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnBorrarTodo.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnBorrarTodo.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnBorrarTodo.Location = New System.Drawing.Point(278, 20)
        Me.BtnBorrarTodo.Name = "BtnBorrarTodo"
        Me.BtnBorrarTodo.Size = New System.Drawing.Size(37, 30)
        Me.BtnBorrarTodo.TabIndex = 47
        Me.BtnBorrarTodo.Text = "AC"
        Me.BtnBorrarTodo.UseVisualStyleBackColor = False
        '
        'BtnPunto
        '
        Me.BtnPunto.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnPunto.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnPunto.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnPunto.Location = New System.Drawing.Point(62, 164)
        Me.BtnPunto.Name = "BtnPunto"
        Me.BtnPunto.Size = New System.Drawing.Size(37, 30)
        Me.BtnPunto.TabIndex = 46
        Me.BtnPunto.Text = ","
        Me.BtnPunto.UseVisualStyleBackColor = False
        '
        'BtnSeno
        '
        Me.BtnSeno.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnSeno.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnSeno.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.BtnSeno.Location = New System.Drawing.Point(191, 164)
        Me.BtnSeno.Name = "BtnSeno"
        Me.BtnSeno.Size = New System.Drawing.Size(37, 30)
        Me.BtnSeno.TabIndex = 45
        Me.BtnSeno.Text = "SIN"
        Me.BtnSeno.UseVisualStyleBackColor = False
        '
        'BtnCoseno
        '
        Me.BtnCoseno.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnCoseno.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnCoseno.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.BtnCoseno.Location = New System.Drawing.Point(235, 164)
        Me.BtnCoseno.Name = "BtnCoseno"
        Me.BtnCoseno.Size = New System.Drawing.Size(37, 30)
        Me.BtnCoseno.TabIndex = 44
        Me.BtnCoseno.Text = "COS"
        Me.BtnCoseno.UseVisualStyleBackColor = False
        '
        'BtnTangente
        '
        Me.BtnTangente.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnTangente.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnTangente.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.BtnTangente.Location = New System.Drawing.Point(278, 164)
        Me.BtnTangente.Name = "BtnTangente"
        Me.BtnTangente.Size = New System.Drawing.Size(37, 30)
        Me.BtnTangente.TabIndex = 43
        Me.BtnTangente.Text = "TAN"
        Me.BtnTangente.UseVisualStyleBackColor = False
        '
        'BtnLogaritmo
        '
        Me.BtnLogaritmo.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnLogaritmo.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnLogaritmo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.BtnLogaritmo.Location = New System.Drawing.Point(191, 128)
        Me.BtnLogaritmo.Name = "BtnLogaritmo"
        Me.BtnLogaritmo.Size = New System.Drawing.Size(37, 30)
        Me.BtnLogaritmo.TabIndex = 42
        Me.BtnLogaritmo.Text = "LOG"
        Me.BtnLogaritmo.UseVisualStyleBackColor = False
        '
        'BtnLogaritmoNatural
        '
        Me.BtnLogaritmoNatural.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnLogaritmoNatural.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnLogaritmoNatural.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.BtnLogaritmoNatural.Location = New System.Drawing.Point(235, 128)
        Me.BtnLogaritmoNatural.Name = "BtnLogaritmoNatural"
        Me.BtnLogaritmoNatural.Size = New System.Drawing.Size(37, 30)
        Me.BtnLogaritmoNatural.TabIndex = 41
        Me.BtnLogaritmoNatural.Text = "LN"
        Me.BtnLogaritmoNatural.UseVisualStyleBackColor = False
        '
        'BtnFactorial
        '
        Me.BtnFactorial.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnFactorial.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnFactorial.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.BtnFactorial.Location = New System.Drawing.Point(278, 128)
        Me.BtnFactorial.Name = "BtnFactorial"
        Me.BtnFactorial.Size = New System.Drawing.Size(37, 30)
        Me.BtnFactorial.TabIndex = 40
        Me.BtnFactorial.Text = "FAC"
        Me.BtnFactorial.UseVisualStyleBackColor = False
        '
        'BtnRaizCuad
        '
        Me.BtnRaizCuad.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnRaizCuad.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnRaizCuad.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnRaizCuad.Location = New System.Drawing.Point(191, 92)
        Me.BtnRaizCuad.Name = "BtnRaizCuad"
        Me.BtnRaizCuad.Size = New System.Drawing.Size(37, 30)
        Me.BtnRaizCuad.TabIndex = 39
        Me.BtnRaizCuad.Text = "²√"
        Me.BtnRaizCuad.UseVisualStyleBackColor = False
        '
        'BtnRaizCub
        '
        Me.BtnRaizCub.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnRaizCub.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnRaizCub.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnRaizCub.Location = New System.Drawing.Point(235, 92)
        Me.BtnRaizCub.Name = "BtnRaizCub"
        Me.BtnRaizCub.Size = New System.Drawing.Size(37, 30)
        Me.BtnRaizCub.TabIndex = 38
        Me.BtnRaizCub.Text = "³√"
        Me.BtnRaizCub.UseVisualStyleBackColor = False
        '
        'BtnRaizN
        '
        Me.BtnRaizN.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnRaizN.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnRaizN.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnRaizN.Location = New System.Drawing.Point(278, 92)
        Me.BtnRaizN.Name = "BtnRaizN"
        Me.BtnRaizN.Size = New System.Drawing.Size(37, 30)
        Me.BtnRaizN.TabIndex = 37
        Me.BtnRaizN.Text = "ⁿ√"
        Me.BtnRaizN.UseVisualStyleBackColor = False
        '
        'BtnExpCuad
        '
        Me.BtnExpCuad.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnExpCuad.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnExpCuad.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnExpCuad.Location = New System.Drawing.Point(191, 56)
        Me.BtnExpCuad.Name = "BtnExpCuad"
        Me.BtnExpCuad.Size = New System.Drawing.Size(37, 30)
        Me.BtnExpCuad.TabIndex = 36
        Me.BtnExpCuad.Text = "x²"
        Me.BtnExpCuad.UseVisualStyleBackColor = False
        '
        'BtnExpCub
        '
        Me.BtnExpCub.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnExpCub.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnExpCub.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnExpCub.Location = New System.Drawing.Point(235, 56)
        Me.BtnExpCub.Name = "BtnExpCub"
        Me.BtnExpCub.Size = New System.Drawing.Size(37, 30)
        Me.BtnExpCub.TabIndex = 35
        Me.BtnExpCub.Text = "x³"
        Me.BtnExpCub.UseVisualStyleBackColor = False
        '
        'BtnExpN
        '
        Me.BtnExpN.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnExpN.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnExpN.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnExpN.Location = New System.Drawing.Point(278, 56)
        Me.BtnExpN.Name = "BtnExpN"
        Me.BtnExpN.Size = New System.Drawing.Size(37, 30)
        Me.BtnExpN.TabIndex = 34
        Me.BtnExpN.Text = "xⁿ"
        Me.BtnExpN.UseVisualStyleBackColor = False
        '
        'BtnCero
        '
        Me.BtnCero.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnCero.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnCero.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnCero.Location = New System.Drawing.Point(19, 164)
        Me.BtnCero.Name = "BtnCero"
        Me.BtnCero.Size = New System.Drawing.Size(37, 30)
        Me.BtnCero.TabIndex = 33
        Me.BtnCero.Text = "0"
        Me.BtnCero.UseVisualStyleBackColor = False
        '
        'BtnBorrar
        '
        Me.BtnBorrar.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnBorrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnBorrar.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnBorrar.Location = New System.Drawing.Point(235, 20)
        Me.BtnBorrar.Name = "BtnBorrar"
        Me.BtnBorrar.Size = New System.Drawing.Size(37, 30)
        Me.BtnBorrar.TabIndex = 32
        Me.BtnBorrar.Text = "C"
        Me.BtnBorrar.UseVisualStyleBackColor = False
        '
        'BtnResultado
        '
        Me.BtnResultado.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnResultado.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnResultado.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnResultado.Location = New System.Drawing.Point(105, 164)
        Me.BtnResultado.Name = "BtnResultado"
        Me.BtnResultado.Size = New System.Drawing.Size(37, 30)
        Me.BtnResultado.TabIndex = 31
        Me.BtnResultado.Text = "="
        Me.BtnResultado.UseVisualStyleBackColor = False
        '
        'BtnNueve
        '
        Me.BtnNueve.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnNueve.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnNueve.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnNueve.Location = New System.Drawing.Point(105, 128)
        Me.BtnNueve.Name = "BtnNueve"
        Me.BtnNueve.Size = New System.Drawing.Size(37, 30)
        Me.BtnNueve.TabIndex = 30
        Me.BtnNueve.Text = "9"
        Me.BtnNueve.UseVisualStyleBackColor = False
        '
        'BtnSeis
        '
        Me.BtnSeis.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnSeis.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnSeis.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnSeis.Location = New System.Drawing.Point(105, 92)
        Me.BtnSeis.Name = "BtnSeis"
        Me.BtnSeis.Size = New System.Drawing.Size(37, 30)
        Me.BtnSeis.TabIndex = 29
        Me.BtnSeis.Text = "6"
        Me.BtnSeis.UseVisualStyleBackColor = False
        '
        'BtnSiete
        '
        Me.BtnSiete.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnSiete.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnSiete.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnSiete.Location = New System.Drawing.Point(19, 128)
        Me.BtnSiete.Name = "BtnSiete"
        Me.BtnSiete.Size = New System.Drawing.Size(37, 30)
        Me.BtnSiete.TabIndex = 28
        Me.BtnSiete.Text = "7"
        Me.BtnSiete.UseVisualStyleBackColor = False
        '
        'BtnOcho
        '
        Me.BtnOcho.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnOcho.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnOcho.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnOcho.Location = New System.Drawing.Point(62, 128)
        Me.BtnOcho.Name = "BtnOcho"
        Me.BtnOcho.Size = New System.Drawing.Size(37, 30)
        Me.BtnOcho.TabIndex = 27
        Me.BtnOcho.Text = "8"
        Me.BtnOcho.UseVisualStyleBackColor = False
        '
        'BtnCinco
        '
        Me.BtnCinco.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnCinco.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnCinco.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnCinco.Location = New System.Drawing.Point(62, 92)
        Me.BtnCinco.Name = "BtnCinco"
        Me.BtnCinco.Size = New System.Drawing.Size(37, 30)
        Me.BtnCinco.TabIndex = 26
        Me.BtnCinco.Text = "5"
        Me.BtnCinco.UseVisualStyleBackColor = False
        '
        'BtnDos
        '
        Me.BtnDos.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnDos.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnDos.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnDos.Location = New System.Drawing.Point(61, 56)
        Me.BtnDos.Name = "BtnDos"
        Me.BtnDos.Size = New System.Drawing.Size(37, 30)
        Me.BtnDos.TabIndex = 25
        Me.BtnDos.Text = "2"
        Me.BtnDos.UseVisualStyleBackColor = False
        '
        'BtnTres
        '
        Me.BtnTres.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnTres.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnTres.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnTres.Location = New System.Drawing.Point(105, 56)
        Me.BtnTres.Name = "BtnTres"
        Me.BtnTres.Size = New System.Drawing.Size(37, 30)
        Me.BtnTres.TabIndex = 24
        Me.BtnTres.Text = "3"
        Me.BtnTres.UseVisualStyleBackColor = False
        '
        'BtnCuatro
        '
        Me.BtnCuatro.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnCuatro.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnCuatro.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnCuatro.Location = New System.Drawing.Point(19, 92)
        Me.BtnCuatro.Name = "BtnCuatro"
        Me.BtnCuatro.Size = New System.Drawing.Size(37, 30)
        Me.BtnCuatro.TabIndex = 23
        Me.BtnCuatro.Text = "4"
        Me.BtnCuatro.UseVisualStyleBackColor = False
        '
        'BtnUno
        '
        Me.BtnUno.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnUno.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnUno.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnUno.Location = New System.Drawing.Point(18, 56)
        Me.BtnUno.Name = "BtnUno"
        Me.BtnUno.Size = New System.Drawing.Size(37, 30)
        Me.BtnUno.TabIndex = 22
        Me.BtnUno.Text = "1"
        Me.BtnUno.UseVisualStyleBackColor = False
        '
        'TxtResultado
        '
        Me.TxtResultado.Location = New System.Drawing.Point(19, 25)
        Me.TxtResultado.Name = "TxtResultado"
        Me.TxtResultado.Size = New System.Drawing.Size(209, 20)
        Me.TxtResultado.TabIndex = 21
        Me.TxtResultado.Text = "0"
        '
        'BtnResta
        '
        Me.BtnResta.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnResta.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnResta.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnResta.Location = New System.Drawing.Point(148, 92)
        Me.BtnResta.Name = "BtnResta"
        Me.BtnResta.Size = New System.Drawing.Size(37, 30)
        Me.BtnResta.TabIndex = 20
        Me.BtnResta.Text = "-"
        Me.BtnResta.UseVisualStyleBackColor = False
        '
        'BtnMultiplicacion
        '
        Me.BtnMultiplicacion.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnMultiplicacion.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnMultiplicacion.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnMultiplicacion.Location = New System.Drawing.Point(148, 128)
        Me.BtnMultiplicacion.Name = "BtnMultiplicacion"
        Me.BtnMultiplicacion.Size = New System.Drawing.Size(37, 30)
        Me.BtnMultiplicacion.TabIndex = 19
        Me.BtnMultiplicacion.Text = "*"
        Me.BtnMultiplicacion.UseVisualStyleBackColor = False
        '
        'BtnDivision
        '
        Me.BtnDivision.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnDivision.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnDivision.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnDivision.Location = New System.Drawing.Point(148, 164)
        Me.BtnDivision.Name = "BtnDivision"
        Me.BtnDivision.Size = New System.Drawing.Size(37, 30)
        Me.BtnDivision.TabIndex = 18
        Me.BtnDivision.Text = "/"
        Me.BtnDivision.UseVisualStyleBackColor = False
        '
        'BtnSuma
        '
        Me.BtnSuma.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BtnSuma.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnSuma.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.BtnSuma.Location = New System.Drawing.Point(148, 56)
        Me.BtnSuma.Name = "BtnSuma"
        Me.BtnSuma.Size = New System.Drawing.Size(37, 30)
        Me.BtnSuma.TabIndex = 17
        Me.BtnSuma.Text = "+"
        Me.BtnSuma.UseVisualStyleBackColor = False
        '
        'LblTitulo
        '
        Me.LblTitulo.AutoSize = True
        Me.LblTitulo.Font = New System.Drawing.Font("Tempus Sans ITC", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTitulo.ForeColor = System.Drawing.Color.White
        Me.LblTitulo.Location = New System.Drawing.Point(4, 5)
        Me.LblTitulo.Name = "LblTitulo"
        Me.LblTitulo.Size = New System.Drawing.Size(206, 31)
        Me.LblTitulo.TabIndex = 1
        Me.LblTitulo.Text = "GenesisCalculator"
        '
        'BtnCerrar
        '
        Me.BtnCerrar.BackgroundImage = CType(resources.GetObject("BtnCerrar.BackgroundImage"), System.Drawing.Image)
        Me.BtnCerrar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnCerrar.FlatAppearance.BorderSize = 0
        Me.BtnCerrar.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent
        Me.BtnCerrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnCerrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCerrar.Location = New System.Drawing.Point(305, 2)
        Me.BtnCerrar.Name = "BtnCerrar"
        Me.BtnCerrar.Size = New System.Drawing.Size(32, 32)
        Me.BtnCerrar.TabIndex = 2
        Me.BtnCerrar.UseVisualStyleBackColor = True
        '
        'BtnMinimizar
        '
        Me.BtnMinimizar.BackgroundImage = CType(resources.GetObject("BtnMinimizar.BackgroundImage"), System.Drawing.Image)
        Me.BtnMinimizar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnMinimizar.FlatAppearance.BorderSize = 0
        Me.BtnMinimizar.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent
        Me.BtnMinimizar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnMinimizar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnMinimizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnMinimizar.Location = New System.Drawing.Point(272, 2)
        Me.BtnMinimizar.Name = "BtnMinimizar"
        Me.BtnMinimizar.Size = New System.Drawing.Size(32, 32)
        Me.BtnMinimizar.TabIndex = 3
        Me.BtnMinimizar.UseVisualStyleBackColor = True
        '
        'LblLink
        '
        Me.LblLink.AutoSize = True
        Me.LblLink.Location = New System.Drawing.Point(163, 207)
        Me.LblLink.Name = "LblLink"
        Me.LblLink.Size = New System.Drawing.Size(156, 13)
        Me.LblLink.TabIndex = 48
        Me.LblLink.TabStop = True
        Me.LblLink.Text = "WWW.GENESISVARGASJ.TK"
        '
        'BtnAbout
        '
        Me.BtnAbout.BackColor = System.Drawing.Color.Silver
        Me.BtnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnAbout.Location = New System.Drawing.Point(19, 202)
        Me.BtnAbout.Name = "BtnAbout"
        Me.BtnAbout.Size = New System.Drawing.Size(75, 23)
        Me.BtnAbout.TabIndex = 49
        Me.BtnAbout.Text = "Acerca De"
        Me.Tooltip.SetToolTip(Me.BtnAbout, "Calculadora Hecha en Visual Basic .NET por Genesis VJ" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Visita mi página web" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "--Pr" & _
                "ogramador en .NET, PHP, Python, Javascript y HTML5")
        Me.BtnAbout.UseVisualStyleBackColor = False
        '
        'Tooltip
        '
        Me.Tooltip.IsBalloon = True
        Me.Tooltip.ToolTipTitle = "Genesis Calculator"
        '
        'FrmCalculadora
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SteelBlue
        Me.ClientSize = New System.Drawing.Size(340, 277)
        Me.Controls.Add(Me.BtnMinimizar)
        Me.Controls.Add(Me.BtnCerrar)
        Me.Controls.Add(Me.LblTitulo)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmCalculadora"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Genesis Calculator"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Private WithEvents BtnBorrarTodo As System.Windows.Forms.Button
    Private WithEvents BtnPunto As System.Windows.Forms.Button
    Private WithEvents BtnSeno As System.Windows.Forms.Button
    Private WithEvents BtnCoseno As System.Windows.Forms.Button
    Private WithEvents BtnTangente As System.Windows.Forms.Button
    Private WithEvents BtnLogaritmo As System.Windows.Forms.Button
    Private WithEvents BtnLogaritmoNatural As System.Windows.Forms.Button
    Private WithEvents BtnFactorial As System.Windows.Forms.Button
    Private WithEvents BtnRaizCuad As System.Windows.Forms.Button
    Private WithEvents BtnRaizCub As System.Windows.Forms.Button
    Private WithEvents BtnRaizN As System.Windows.Forms.Button
    Private WithEvents BtnExpCuad As System.Windows.Forms.Button
    Private WithEvents BtnExpCub As System.Windows.Forms.Button
    Private WithEvents BtnExpN As System.Windows.Forms.Button
    Private WithEvents BtnCero As System.Windows.Forms.Button
    Private WithEvents BtnBorrar As System.Windows.Forms.Button
    Private WithEvents BtnResultado As System.Windows.Forms.Button
    Private WithEvents BtnNueve As System.Windows.Forms.Button
    Private WithEvents BtnSeis As System.Windows.Forms.Button
    Private WithEvents BtnSiete As System.Windows.Forms.Button
    Private WithEvents BtnOcho As System.Windows.Forms.Button
    Private WithEvents BtnCinco As System.Windows.Forms.Button
    Private WithEvents BtnDos As System.Windows.Forms.Button
    Private WithEvents BtnTres As System.Windows.Forms.Button
    Private WithEvents BtnCuatro As System.Windows.Forms.Button
    Private WithEvents BtnUno As System.Windows.Forms.Button
    Private WithEvents TxtResultado As System.Windows.Forms.TextBox
    Private WithEvents BtnResta As System.Windows.Forms.Button
    Private WithEvents BtnMultiplicacion As System.Windows.Forms.Button
    Private WithEvents BtnDivision As System.Windows.Forms.Button
    Private WithEvents BtnSuma As System.Windows.Forms.Button
    Friend WithEvents LblTitulo As System.Windows.Forms.Label
    Friend WithEvents BtnCerrar As System.Windows.Forms.Button
    Friend WithEvents BtnMinimizar As System.Windows.Forms.Button
    Friend WithEvents LblLink As System.Windows.Forms.LinkLabel
    Friend WithEvents BtnAbout As System.Windows.Forms.Button
    Friend WithEvents Tooltip As System.Windows.Forms.ToolTip

End Class
