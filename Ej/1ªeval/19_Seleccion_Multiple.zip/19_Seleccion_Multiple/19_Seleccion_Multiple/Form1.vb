﻿Public Class frmSeleccionMultiple

    Private Sub btnSelecionar_Click(sender As System.Object, e As System.EventArgs) Handles btnSelecionar.Click

        deselecionarTodo()

        Dim n As Integer = numIndices.Value
        Dim num As Integer

        For i = 0 To lstAnimales.Items.Count - 1
            num = i + 1
            If num Mod n = 0 Then
                lstAnimales.SetSelected(i, True)
            End If
        Next

        For i = 0 To lstDestino.Items.Count - 1
            num = i + 1
            If num Mod n = 0 Then
                lstDestino.SetSelected(i, True)
            End If
        Next

    End Sub

    Private Sub btnMover_Click(sender As System.Object, e As System.EventArgs) Handles btnMover.Click

        While lstAnimales.SelectedIndex <> -1
            Dim indice As Integer = lstAnimales.SelectedIndex
            lstDestino.Items.Add(lstAnimales.Items(indice))
            lstAnimales.Items.Remove(lstAnimales.Items(indice))
        End While

        'For i = lstAnimales.Items.Count - 1 To 0 Step -1
        '    If (lstAnimales.GetSelected(i)) Then
        '        lstDestino.Items.Insert(0, lstAnimales.Items(i))
        '        lstAnimales.Items.RemoveAt(i)
        '    End If
        'Next

        deselecionarTodo()

    End Sub

    Private Sub btnDevolver_Click(sender As System.Object, e As System.EventArgs) Handles btnDevolver.Click
        While lstDestino.SelectedIndex <> -1
            Dim indice As Integer = lstDestino.SelectedIndex
            lstAnimales.Items.Add(lstDestino.Items(indice))
            lstDestino.Items.Remove(lstDestino.Items(indice))
        End While
        deselecionarTodo()
    End Sub

    Sub deselecionarTodo()
        lstAnimales.SelectedIndex = -1
        lstDestino.SelectedIndex = -1
    End Sub

    Private Sub btnSalir_Click(sender As System.Object, e As System.EventArgs) Handles btnSalir.Click
        Me.Dispose()
    End Sub
End Class
