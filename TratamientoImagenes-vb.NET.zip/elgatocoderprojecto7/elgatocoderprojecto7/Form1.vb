﻿Imports System.IO

'Este codigo fuente pertenece a elgatocoder.com, porfavor no borres este comentario. www.elgatocoder.com un nuevo projecto cada semana visitanos
Public Class Form1
    Dim bmap As Bitmap

    Private Sub AbrirToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AbrirToolStripMenuItem.Click
        OpenFileDialog1.Filter = "Imagenes|*.GIF;*.TIF;*.JPG;*.PNG"
        OpenFileDialog1.ShowDialog()
        If OpenFileDialog1.FileName = "" Then Exit Sub

        PictureBox1.Image = Image.FromFile(OpenFileDialog1.FileName)
        PictureBox1.Width = PictureBox1.Height * PictureBox1.Image.Width / PictureBox1.Image.Height
        Me.Text = "Tamaño: " & PictureBox1.Image.Width.ToString & ", " & PictureBox1.Image.Height.ToString & ""
    End Sub




    Private Sub contornoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles contornoToolStripMenuItem.Click
        bmap = New Bitmap(PictureBox1.Image)
        PictureBox1.Image = bmap
        Dim tempbmp As New Bitmap(PictureBox1.Image)
        Dim i, j As Integer
        Dim DispX As Integer = 1, DispY As Integer = 1
        Dim red, green, blue As Integer
        With tempbmp
            For i = 0 To .Height - 2
                For j = 0 To .Width - 2
                    Dim pixel1, pixel2 As System.Drawing.Color
                    pixel1 = .GetPixel(j, i)
                    pixel2 = .GetPixel(j + DispX, i + DispY)
                    red = Math.Min(Math.Abs(CInt(pixel1.R) - CInt(pixel2.R)) + 128, 255)
                    green = Math.Min(Math.Abs(CInt(pixel1.G) - CInt(pixel2.G)) + 128, 255)
                    blue = Math.Min(Math.Abs(CInt(pixel1.B) - CInt(pixel2.B)) + 128, 255)
                    bmap.SetPixel(j, i, Color.FromArgb(red, green, blue))
                Next

                If i Mod 10 = 0 Then
                    PictureBox1.Invalidate()
                    PictureBox1.Refresh()
                    Me.Text = Int(100 * i / (PictureBox1.Image.Height - 2)).ToString & "%"
                End If
            Next
        End With
        PictureBox1.Refresh()

        Me.Text = "Tamaño: " & PictureBox1.Image.Width.ToString & ", " & PictureBox1.Image.Height.ToString & ""
        ToolStripStatusLabel2.Text = "Contorno Aplicado Satisfactoriamente"

    End Sub

    Private Sub ToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem1.Click


        If PictureBox1.Image Is Nothing Then

            MsgBox("Actualmente no se encuentra una imagen abierta", MsgBoxStyle.Exclamation)

        Else

            bmap = New Bitmap(PictureBox1.Image)
            PictureBox1.Image = bmap
            Dim tempbmp As New Bitmap(PictureBox1.Image)
            Dim i As Integer, j As Integer
            Dim DX As Integer
            Dim DY As Integer
            Dim red As Integer, green As Integer, blue As Integer
            With tempbmp
                For i = 3 To .Height - 3
                    For j = 3 To .Width - 3
                        DX = Rnd() * 4 - 2
                        DY = Rnd() * 4 - 2
                        red = .GetPixel(j + DX, i + DY).R
                        green = .GetPixel(j + DX, i + DY).G
                        blue = .GetPixel(j + DX, i + DY).B
                        bmap.SetPixel(j, i, Color.FromArgb(red, green, blue))
                    Next
                    Me.Text = Int(100 * i / (.Height - 2)).ToString & "%"
                    If i Mod 10 = 0 Then
                        PictureBox1.Invalidate()
                        PictureBox1.Refresh()
                        Me.Text = Int(100 * i / (PictureBox1.Image.Height - 2)).ToString & "%"
                    End If
                Next
            End With
            PictureBox1.Refresh()


            ToolStripStatusLabel2.Text = "Efecto Difuso Aplicado Satisfactoriamente"
            Me.Text = "Tamaño: " & PictureBox1.Image.Width.ToString & ", " & PictureBox1.Image.Height.ToString & ""

        End If

    End Sub


    Private Sub EnfocarToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EnfocarToolStripMenuItem.Click

        If PictureBox1.Image Is Nothing Then

            MsgBox("Actualmente no se encuentra una imagen abierta", MsgBoxStyle.Exclamation)

        Else

            bmap = New Bitmap(PictureBox1.Image)
            PictureBox1.Image = bmap
            Dim tempbmp As New Bitmap(PictureBox1.Image)
            Dim DX As Integer = 1
            Dim DY As Integer = 1
            Dim red, green, blue As Integer

            Dim i, j As Integer
            With tempbmp
                For i = DX To .Height - DX - 1
                    For j = DY To .Width - DY - 1
                        red = CInt(.GetPixel(j, i).R) + 0.5 * CInt((.GetPixel(j, i).R) - CInt(.GetPixel(j - DX, i - DY).R))
                        green = CInt(.GetPixel(j, i).G) + 0.7 * CInt((.GetPixel(j, i).G) - CInt(.GetPixel(j - DX, i - DY).G))
                        blue = CInt(.GetPixel(j, i).B) + 0.5 * CInt((.GetPixel(j, i).B - CInt(.GetPixel(j - DX, i - DY).B)))
                        red = Math.Min(Math.Max(red, 0), 255)
                        green = Math.Min(Math.Max(green, 0), 255)
                        blue = Math.Min(Math.Max(blue, 0), 255)
                        bmap.SetPixel(j, i, Color.FromArgb(red, green, blue))
                    Next
                    If i Mod 10 = 0 Then
                        PictureBox1.Invalidate()
                        Me.Text = Int(100 * i / (PictureBox1.Image.Height - 2)).ToString & "%"
                        PictureBox1.Refresh()
                    End If
                Next
            End With
            PictureBox1.Refresh()
            ToolStripStatusLabel2.Text = "Efecto Resaltar Aplicado Satisfactoriamente"
            Me.Text = "Tamaño: " & PictureBox1.Image.Width.ToString & ", " & PictureBox1.Image.Height.ToString & ""

        End If

    End Sub

    Private Sub SuavizarToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SuavizarToolStripMenuItem.Click

        If PictureBox1.Image Is Nothing Then

            MsgBox("Actualmente no se encuentra una imagen abierta", MsgBoxStyle.Exclamation)

        Else

            bmap = New Bitmap(PictureBox1.Image)
            PictureBox1.Image = bmap
            Dim tempbmp As New Bitmap(PictureBox1.Image)
            Dim DX As Integer = 1
            Dim DY As Integer = 1
            Dim red, green, blue As Integer

            Dim i, j As Integer
            With tempbmp
                For i = DX To .Height - DX - 1
                    For j = DY To .Width - DY - 1
                        red = CInt((CInt(.GetPixel(j - 1, i - 1).R) + _
                                CInt(.GetPixel(j - 1, i).R) + _
                                CInt(.GetPixel(j - 1, i + 1).R) + _
                                CInt(.GetPixel(j, i - 1).R) + _
                                CInt(.GetPixel(j, i).R) + _
                                CInt(.GetPixel(j, i + 1).R) + _
                                CInt(.GetPixel(j + 1, i - 1).R) + _
                                CInt(.GetPixel(j + 1, i).R) + _
                                CInt(.GetPixel(j + 1, i + 1).R)) / 9)

                        green = CInt((CInt(.GetPixel(j - 1, i - 1).G) + _
                                CInt(.GetPixel(j - 1, i).G) + _
                                CInt(.GetPixel(j - 1, i + 1).G) + _
                                CInt(.GetPixel(j, i - 1).G) + _
                                CInt(.GetPixel(j, i).G) + _
                                CInt(.GetPixel(j, i + 1).G) + _
                                CInt(.GetPixel(j + 1, i - 1).G) + _
                                CInt(.GetPixel(j + 1, i).G) + _
                                CInt(.GetPixel(j + 1, i + 1).G)) / 9)

                        blue = CInt((CInt(.GetPixel(j - 1, i - 1).B) + _
                                CInt(.GetPixel(j - 1, i).B) + _
                                CInt(.GetPixel(j - 1, i + 1).B) + _
                                CInt(.GetPixel(j, i - 1).B) + _
                                CInt(.GetPixel(j, i).B) + _
                                CInt(.GetPixel(j, i + 1).B) + _
                                CInt(.GetPixel(j + 1, i - 1).B) + _
                                CInt(.GetPixel(j + 1, i).B) + _
                                CInt(.GetPixel(j + 1, i + 1).B)) / 9)
                        red = Math.Min(Math.Max(red, 0), 255)
                        green = Math.Min(Math.Max(green, 0), 255)
                        blue = Math.Min(Math.Max(blue, 0), 255)
                        bmap.SetPixel(j, i, Color.FromArgb(red, green, blue))
                    Next
                    If i Mod 10 = 0 Then
                        PictureBox1.Invalidate()
                        PictureBox1.Refresh()
                        Me.Text = Int(100 * i / (PictureBox1.Image.Height - 2)).ToString & "%"
                    End If
                Next
            End With
            PictureBox1.Refresh()
            ToolStripStatusLabel2.Text = "Efecto Suavisar Aplicado Satisfactoriamente"
            Me.Text = "Tamaño: " & PictureBox1.Image.Width.ToString & ", " & PictureBox1.Image.Height.ToString & ""

        End If


    End Sub

    Private Sub ToolStripMenuItem8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem8.Click
        If PictureBox1.Image Is Nothing Then
            MsgBox("Actualmente no se encuentra una imagen abierta", MsgBoxStyle.Exclamation)
            PictureBox1.Refresh()
        Else

            PictureBox1.Image.Dispose()
            PictureBox1.Image = Nothing
        End If

    End Sub

    Private Sub RotarIzquierdaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RotarIzquierdaToolStripMenuItem.Click

        If PictureBox1.Image Is Nothing Then

            MsgBox("Actualmente no se encuentra una imagen abierta", MsgBoxStyle.Exclamation)

        Else

            PictureBox1.Width = PictureBox1.Width * 2
            PictureBox1.Height = PictureBox1.Height * 2

        End If

    End Sub

    Private Sub RotarDerechaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RotarDerechaToolStripMenuItem.Click

        If PictureBox1.Image Is Nothing Then

            MsgBox("Actualmente no se encuentra una imagen abierta", MsgBoxStyle.Exclamation)

        Else

            PictureBox1.Width = PictureBox1.Width / 2
            PictureBox1.Height = PictureBox1.Height / 2

        End If

    End Sub

    Private Sub VoltearHorizontalToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VoltearHorizontalToolStripMenuItem.Click

        If PictureBox1.Image Is Nothing Then

            MsgBox("Actualmente no se encuentra una imagen abierta", MsgBoxStyle.Exclamation)

        Else

            PictureBox1.Width = PictureBox1.Image.Width
            PictureBox1.Height = PictureBox1.Image.Height

        End If


    End Sub

    Private Sub ToolStripMenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem3.Click
        If PictureBox1.Image Is Nothing Then

            MsgBox("Actualmente no se encuentra una imagen abierta", MsgBoxStyle.Exclamation)

        Else

            PictureBox1.Image.RotateFlip(RotateFlipType.Rotate270FlipNone)
            PictureBox1.Width = PictureBox1.Height * PictureBox1.Image.Width / PictureBox1.Image.Height

        End If

    End Sub

    Private Sub ToolStripMenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem4.Click

        If PictureBox1.Image Is Nothing Then

            MsgBox("Actualmente no se encuentra una imagen abierta", MsgBoxStyle.Exclamation)

        Else

            PictureBox1.Image.RotateFlip(RotateFlipType.Rotate90FlipNone)
            PictureBox1.Width = PictureBox1.Height * PictureBox1.Image.Width / PictureBox1.Image.Height

        End If


    End Sub

    Private Sub ToolStripMenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem5.Click
        If PictureBox1.Image Is Nothing Then

            MsgBox("Actualmente no se encuentra una imagen abierta", MsgBoxStyle.Exclamation)

        Else

            PictureBox1.Image.RotateFlip(RotateFlipType.RotateNoneFlipX)
            PictureBox1.Refresh()

        End If

    End Sub

    Private Sub ToolStripMenuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem6.Click

        If PictureBox1.Image Is Nothing Then

            MsgBox("Actualmente no se encuentra una imagen abierta", MsgBoxStyle.Exclamation)

        Else

            PictureBox1.Image.RotateFlip(RotateFlipType.RotateNoneFlipY)
            PictureBox1.Refresh()

        End If

    End Sub

    Private Sub ToolStripMenuItem7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem7.Click

        Dim saveFileDialog1 As New SaveFileDialog()

        saveFileDialog1.Filter = "Bitmap(*.bmp)|*.bmp|(*.jpg)|*.jpg|(*.png)|*.png"
        saveFileDialog1.FilterIndex = 2
        saveFileDialog1.RestoreDirectory = True



        If PictureBox1.Image Is Nothing Then
            MsgBox("Actualmente no se encuentra una imagen abierta", MsgBoxStyle.Exclamation)

        Else
            If saveFileDialog1.ShowDialog() = DialogResult.OK Then
                PictureBox1.Image.Save(saveFileDialog1.FileName)

            End If
        End If
    End Sub

    Private Sub ElGatoCoderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ElGatoCoderToolStripMenuItem.Click

        System.Diagnostics.Process.Start("http://elgatocoder.com")
    End Sub
End Class
